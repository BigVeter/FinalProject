--
-- PostgreSQL database dump
--

-- Dumped from database version 12.10
-- Dumped by pg_dump version 14.2

-- Started on 2023-04-23 15:53:39

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 3758 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 203 (class 1259 OID 240763)
-- Name: category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category (
    id integer NOT NULL,
    name character varying(255)
);


--
-- TOC entry 202 (class 1259 OID 240761)
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3759 (class 0 OID 0)
-- Dependencies: 202
-- Name: category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.category_id_seq OWNED BY public.category.id;


--
-- TOC entry 205 (class 1259 OID 240771)
-- Name: image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.image (
    id integer NOT NULL,
    file_name character varying(255),
    product_id integer NOT NULL
);


--
-- TOC entry 204 (class 1259 OID 240769)
-- Name: image_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3760 (class 0 OID 0)
-- Dependencies: 204
-- Name: image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.image_id_seq OWNED BY public.image.id;


--
-- TOC entry 207 (class 1259 OID 240779)
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    count integer NOT NULL,
    date_time timestamp(6) without time zone,
    number character varying(255),
    price real NOT NULL,
    status smallint,
    person_id integer NOT NULL,
    product_id integer NOT NULL
);


--
-- TOC entry 206 (class 1259 OID 240777)
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3761 (class 0 OID 0)
-- Dependencies: 206
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- TOC entry 209 (class 1259 OID 240787)
-- Name: person; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person (
    id integer NOT NULL,
    login character varying(100),
    password character varying(255),
    role character varying(255)
);


--
-- TOC entry 208 (class 1259 OID 240785)
-- Name: person_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.person_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3762 (class 0 OID 0)
-- Dependencies: 208
-- Name: person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.person_id_seq OWNED BY public.person.id;


--
-- TOC entry 211 (class 1259 OID 240798)
-- Name: product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product (
    id integer NOT NULL,
    date_time timestamp(6) without time zone,
    description text NOT NULL,
    price real NOT NULL,
    seller character varying(255) NOT NULL,
    title text NOT NULL,
    warehouse character varying(255) NOT NULL,
    category_id integer NOT NULL,
    CONSTRAINT product_price_check CHECK ((price >= (1)::double precision))
);


--
-- TOC entry 213 (class 1259 OID 240810)
-- Name: product_cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_cart (
    id integer NOT NULL,
    person_id integer,
    product_id integer
);


--
-- TOC entry 212 (class 1259 OID 240808)
-- Name: product_cart_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_cart_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3763 (class 0 OID 0)
-- Dependencies: 212
-- Name: product_cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_cart_id_seq OWNED BY public.product_cart.id;


--
-- TOC entry 210 (class 1259 OID 240796)
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3764 (class 0 OID 0)
-- Dependencies: 210
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.product.id;


--
-- TOC entry 3588 (class 2604 OID 240766)
-- Name: category id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category ALTER COLUMN id SET DEFAULT nextval('public.category_id_seq'::regclass);


--
-- TOC entry 3589 (class 2604 OID 240774)
-- Name: image id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image ALTER COLUMN id SET DEFAULT nextval('public.image_id_seq'::regclass);


--
-- TOC entry 3590 (class 2604 OID 240782)
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- TOC entry 3591 (class 2604 OID 240790)
-- Name: person id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person ALTER COLUMN id SET DEFAULT nextval('public.person_id_seq'::regclass);


--
-- TOC entry 3592 (class 2604 OID 240801)
-- Name: product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- TOC entry 3594 (class 2604 OID 240813)
-- Name: product_cart id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_cart ALTER COLUMN id SET DEFAULT nextval('public.product_cart_id_seq'::regclass);


--
-- TOC entry 3742 (class 0 OID 240763)
-- Dependencies: 203
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.category VALUES (1, 'МЕБЕЛЬ');
INSERT INTO public.category VALUES (2, 'ТЕХНИКА');
INSERT INTO public.category VALUES (3, 'ОДЕЖДА');


--
-- TOC entry 3744 (class 0 OID 240771)
-- Dependencies: 205
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.image VALUES (21, '19ae5ac7-5aab-419b-8fbd-0d0c43d0724c.1 (5).jpg', 5);
INSERT INTO public.image VALUES (22, 'cc29fcf5-f767-4357-b13c-807d671ec29a.1 (4).jpg', 5);
INSERT INTO public.image VALUES (23, '73464a44-0d26-46d3-95b3-c8dd0d03c68b.1 (3).jpg', 5);
INSERT INTO public.image VALUES (24, 'f2e58f33-572c-4cee-bbe2-3feeed59f22a.1 (2).jpg', 5);
INSERT INTO public.image VALUES (25, 'dad985fe-14ad-4a8e-83ac-e936d75e6f88.1 (1).jpg', 5);
INSERT INTO public.image VALUES (26, '48522481-b2a5-4a04-9294-25b6f5752ae6.3 (1).jpg', 6);
INSERT INTO public.image VALUES (27, '5c7bf1ad-4c4c-476d-ad2e-04cbb3d6da36.3 (2).jpg', 6);
INSERT INTO public.image VALUES (28, 'b0e6d1aa-e3e8-4120-b1f5-38b1562d85bb.3 (3).jpg', 6);
INSERT INTO public.image VALUES (29, '62ede561-008e-46c7-aac3-6211ddec8d29.3 (4).jpg', 6);
INSERT INTO public.image VALUES (30, '7107d8b0-3467-4981-812c-c46a6102b7f0.3 (5).jpg', 6);
INSERT INTO public.image VALUES (51, '83724590-07bf-4dde-bf7e-5bea3dd21d04.36 (5).jpg', 11);
INSERT INTO public.image VALUES (52, '02537c34-0615-4229-b03b-45b736337fb3.36 (4).jpg', 11);
INSERT INTO public.image VALUES (53, '2fdfc4ec-79ca-4e6d-9e88-30fc74d3f009.36 (3).jpg', 11);
INSERT INTO public.image VALUES (54, 'cca2187c-9a84-431d-91df-702ba170f951.36 (2).jpg', 11);
INSERT INTO public.image VALUES (55, '6e637d8e-3ac3-49ad-a7b5-74d573e3750d.36 (1).jpg', 11);
INSERT INTO public.image VALUES (56, '41ed3189-b01b-4f1c-adf9-26bc950a4c11.78 (1).jpg', 12);
INSERT INTO public.image VALUES (57, '5c5347df-6216-4203-8e13-34df74e244b6.78 (2).jpg', 12);
INSERT INTO public.image VALUES (58, '029ab91b-badd-4f93-926a-8d2aa0c2ec49.78 (3).jpg', 12);
INSERT INTO public.image VALUES (59, 'cd965dcc-3cf7-4318-a454-5841f0d37b45.78 (4).jpg', 12);
INSERT INTO public.image VALUES (60, '28a34b32-f6c6-4a75-9052-641374451508.78 (5).jpg', 12);
INSERT INTO public.image VALUES (66, '48f56054-c1e9-4851-bbf2-0903d2e99fd5.64 (1).jpg', 14);
INSERT INTO public.image VALUES (67, '5b8de587-2e05-4080-a3a7-c92736ffb0d3.64 (2).jpg', 14);
INSERT INTO public.image VALUES (68, '2d906f73-e38d-44b2-a510-1cecc8d6d4a9.64 (3).jpg', 14);
INSERT INTO public.image VALUES (69, '4329d279-549f-4e9c-87e6-a0f2d5fd091b.64 (4).jpg', 14);
INSERT INTO public.image VALUES (70, 'ae8aa0cf-46e7-49dd-b8c3-b7c68bfe6416.64 (5).jpg', 14);
INSERT INTO public.image VALUES (71, '3b3db83e-2735-4009-b0b5-074836c820d7.19 (5).jpg', 15);
INSERT INTO public.image VALUES (72, 'dc987001-143f-471c-aa45-544c224fcbcb.19 (4).jpg', 15);
INSERT INTO public.image VALUES (73, '7006fab6-4fed-4c60-8ed7-efc8caaf3ac7.19 (3).jpg', 15);
INSERT INTO public.image VALUES (74, '857cc77e-2447-4964-bb30-64e41c95ac8a.19 (2).jpg', 15);
INSERT INTO public.image VALUES (75, '9ca7f320-a89e-434f-a3cd-164d9faf1c4f.19 (1).jpg', 15);


--
-- TOC entry 3746 (class 0 OID 240779)
-- Dependencies: 207
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.orders VALUES (10, 1, '2023-04-23 14:05:18.069833', '96e8d415-069f-407a-bdc6-f17723e2ebab', 3250, 1, 2, 12);
INSERT INTO public.orders VALUES (12, 1, '2023-04-23 14:43:32.320017', '55e99322-595d-4968-bef2-8d034966a30e', 1826, 1, 2, 11);
INSERT INTO public.orders VALUES (13, 1, '2023-04-23 14:43:32.606975', '55e99322-595d-4968-bef2-8d034966a30e', 34999, 1, 2, 6);
INSERT INTO public.orders VALUES (14, 1, '2023-04-23 14:57:21.520189', '9df46f27-ab8f-47ee-be6d-9348fd3e246c', 5010, 1, 2, 14);
INSERT INTO public.orders VALUES (15, 1, '2023-04-23 14:57:21.926148', '9df46f27-ab8f-47ee-be6d-9348fd3e246c', 3250, 1, 2, 12);


--
-- TOC entry 3748 (class 0 OID 240787)
-- Dependencies: 209
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.person VALUES (2, 'user1', '$2a$10$mZaWsck/98c7kiMrLoOtS.y00YseJBRI/UsR.zyZ8WI3yp/cNI36O', 'ROLE_USER');
INSERT INTO public.person VALUES (1, 'admin', '$2a$10$TAyzsOi6wPovaKUoHJBCMujIQVAbQ0yWtbo2mhqkRpHOvMxdFbcGq', 'ROLE_ADMIN');
INSERT INTO public.person VALUES (3, 'user2', '$2a$10$sl/NPSh9fiwNoYf0EVFPJ.siapicC6uZtyop/gHJZRAnZhbHydhGu', 'ROLE_USER');


--
-- TOC entry 3750 (class 0 OID 240798)
-- Dependencies: 211
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.product VALUES (5, NULL, 'Трехдверный шкаф-купе BOSS WHITE шириной 240 см — это вместительная система хранения вещей для спальни, прихожей или гостиной. Внутреннее пространство разделено на три отделения: в которых, установлено 9 полок и 2 штанги. Двери купе позволят рационально использовать пространство комнаты. Для крепления фасадов мы используем новую системы раздвижных дверей Hettich Top Line M. Верхняя ходовая направляющая скрыта, она обеспечивает максимальную плавность хода и выдерживает нагрузку до 40 кг. BOSS WHITE 240 в лаконичном дизайне украсит собой любой интерьер и обеспечит надёжное хранение вашей одежды.', 58888, 'МНОГО МЕБЕЛИ', 'Шкаф-купе BOSS WHITE - 240', 'Ангарск', 1);
INSERT INTO public.product VALUES (11, '2023-04-22 19:46:32.47353', 'Джинсы для мальчика от бренда TIHEYA - это лучшее решение для вашего ребенка подростка. В этом летнем сезоне джинса – это настоящий тренд. Она не только подходит для мужского и женского гардероба, но и смотрится прекрасно на детской одежде. В наличии большой размерный ряд, что позволит подобрать модель джоггеров для любого типажа фигуры. На полках магазинов вы можете увидеть широкий выбор джинсовых шорт, брюк и юбок для мальчиков, девочек и подростков. Среди детской одежды джинсовые вещи также представлены в различных стилях: детский и подростковый, оверсайз и облегающий. Некоторые модели украшены надписями или разноцветными резинками. Синий деним все еще остается самым популярным цветом. Однако, многие дизайнеры также добавляют разнообразие, например, голубые или синие оттенки. Одежду из денима можно носить как в летний, так и весенний сезон. Она легко сочетается с другими вещами и позволяет создавать различные образы. Кроме того, джинсу можно утеплить и продолжать носить и в холодные дни и зимний сезон. Так что, если вы ищете стильный и практичный вариант для вашего ребенка – обратите внимание на джинсовую одежду и наши спортивные штаны. Она современна, удобна и всегда в моде.', 1826, 'Wildberries', 'Джинсы для мальчика на резинке', 'Иркутск', 3);
INSERT INTO public.product VALUES (12, '2023-04-22 19:50:56.343662', 'Стильные джинсы для мальчика, выполненные из премиального хлопка. Штаны детские на широком поясе со вшитой эластичной резинкой. Джоггеры дополнены спереди двумя прорезными карманами, сзади двумя накладными. Джинсы прямые, пояс дополнен шлевками для ремня. Эффектные джинсы детские - новый тренд 2023 года. Материал: джинсовая ткань. Подойдут для любого возраста - подростков, парней и мальчиков в школу, одежда оверсайз. Джинсы отличный вариант не только для лета, но и для весны. Также модель идеально подойдет для прогулок в теплую осень. Поэтому с ним Вы точно останетесь в выигрыше и сможете проносить такую модель в течение нескольких сезонов. В нашей коллекции джинсы и брюки представлены в широкой цветовой гамме - синие, серые, голубые, черные. Джинсы детские будут отлично смотреться с футболкой, худи и толстовкой, рубашкой и свитшотом. Ждем Вас!', 3250, 'Wildberries', 'Джинсы для пацана на резинке', 'Иркутск', 3);
INSERT INTO public.product VALUES (14, '2023-04-22 20:02:46.484481', 'Мультиварка-скороварка Midea MPC-6002 станет Вашим верным кухонным помощником и поможет сэкономить время. Программы с давлением готовят намного быстрее: рис/гречка сварится за 10-15 мин, а холодец всего за 2,5 часа. Устройство работает и как скороварка, и как мультиварка (без давления). На программах без давления можно приготовить такие блюда как йогурт , испечь хлеб или пирог. Режим Мультиповар позволяет самостоятельно устанавливать время приготовления (от 1 мин до 12 ч) и температуру (от 30 до 160 С).Книга рецептов на 106 разнообразных блюд. Модель имеет 5 литровую чашу с лицензионным японским антипригарным покрытием DAIKIN. Толщина чаши 1,8 мм (стандартно производители используют чашу 1 мм). Рекомендуется использовать до 2/3 объема чаши.Съемная крышка - это удобство при готовке, чистке и хранении. Крышка и паровой клапан легко снимаются. Чашу, крышку, паровой клапан и все аксессуары можно мыть в посудомоечной машине.', 5010, 'Технопоинт', 'Мультиварка-скороварка Midea MPC-6002', 'Ангарск', 2);
INSERT INTO public.product VALUES (15, '2023-04-22 20:07:52.151778', 'Кофеварка — бытовое устройство для приготовления кофе без необходимости кипячения воды в отдельной ёмкости.

Суть работы кофеварки сводится к следующему: Засыпаете кофе, а также заливаете воду в прибор, и нажимаете кнопку включения. Дальше устройство само приготовит Вам кофе.

Конечно же, как и большинство техники, кофеварка имеет свои виды, как простенькие, так и сложные. Давайте рассмотрим, какие виды кофеварки существует.', 38900, 'Технопоинт', 'Кофемашина PACM 2055AC', 'Ангарск', 2);
INSERT INTO public.product VALUES (6, NULL, 'Шкаф линейки BOSS new великолепный представитель современного дизайна, отлично подходит для гостиной, спальни или гардеробной. Модули легко скрепляются между собой создавая вместительную и удобную систему хранения. Внутреннее пространство структурировано таким образом, чтобы максимально компактно располагать одежду и оперативно находить необходимую вещь за счет хорошего визуального обзора. Лицевая поверхность центральной двери представляет собой большое зеркало, удобное при примерке и выборе гардероба. Модели BOSS new отлично сочетаются с кроватями, комодами, тумбами и столами, выполненными в цвете крафт табачный или сонома. Использование надежной ЛДСП, имеющей все необходимые сертификаты соответствия гарантирует безопасное и комфортное использование.', 33800, 'МНОГО МЕБЕЛИ', 'ШКАФ BOSS-180 Крафт табачный', 'Ангарск', 1);


--
-- TOC entry 3752 (class 0 OID 240810)
-- Dependencies: 213
-- Data for Name: product_cart; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3765 (class 0 OID 0)
-- Dependencies: 202
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.category_id_seq', 3, true);


--
-- TOC entry 3766 (class 0 OID 0)
-- Dependencies: 204
-- Name: image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.image_id_seq', 80, true);


--
-- TOC entry 3767 (class 0 OID 0)
-- Dependencies: 206
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 15, true);


--
-- TOC entry 3768 (class 0 OID 0)
-- Dependencies: 208
-- Name: person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_id_seq', 3, true);


--
-- TOC entry 3769 (class 0 OID 0)
-- Dependencies: 212
-- Name: product_cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_cart_id_seq', 24, true);


--
-- TOC entry 3770 (class 0 OID 0)
-- Dependencies: 210
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_id_seq', 16, true);


--
-- TOC entry 3596 (class 2606 OID 240768)
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- TOC entry 3598 (class 2606 OID 240776)
-- Name: image image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT image_pkey PRIMARY KEY (id);


--
-- TOC entry 3600 (class 2606 OID 240784)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- TOC entry 3602 (class 2606 OID 240795)
-- Name: person person_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (id);


--
-- TOC entry 3608 (class 2606 OID 240815)
-- Name: product_cart product_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_cart
    ADD CONSTRAINT product_cart_pkey PRIMARY KEY (id);


--
-- TOC entry 3604 (class 2606 OID 240807)
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- TOC entry 3606 (class 2606 OID 240817)
-- Name: product uk_qka6vxqdy1dprtqnx9trdd47c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT uk_qka6vxqdy1dprtqnx9trdd47c UNIQUE (title);


--
-- TOC entry 3610 (class 2606 OID 240823)
-- Name: orders fk1b0m4muwx1t377w9if3w6wwqn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk1b0m4muwx1t377w9if3w6wwqn FOREIGN KEY (person_id) REFERENCES public.person(id);


--
-- TOC entry 3612 (class 2606 OID 240833)
-- Name: product fk1mtsbur82frn64de7balymq9s; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT fk1mtsbur82frn64de7balymq9s FOREIGN KEY (category_id) REFERENCES public.category(id);


--
-- TOC entry 3611 (class 2606 OID 240828)
-- Name: orders fk787ibr3guwp6xobrpbofnv7le; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk787ibr3guwp6xobrpbofnv7le FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- TOC entry 3609 (class 2606 OID 240818)
-- Name: image fkgpextbyee3uk9u6o2381m7ft1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT fkgpextbyee3uk9u6o2381m7ft1 FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- TOC entry 3614 (class 2606 OID 240843)
-- Name: product_cart fkhpnrxdy3jhujameyod08ilvvw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_cart
    ADD CONSTRAINT fkhpnrxdy3jhujameyod08ilvvw FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- TOC entry 3613 (class 2606 OID 240838)
-- Name: product_cart fksgnkc1ko2i1o9yr2p63ysq3rn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_cart
    ADD CONSTRAINT fksgnkc1ko2i1o9yr2p63ysq3rn FOREIGN KEY (person_id) REFERENCES public.person(id);


-- Completed on 2023-04-23 15:53:55

--
-- PostgreSQL database dump complete
--

